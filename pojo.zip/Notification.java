package day8;

import java.sql.Timestamp;

public class Notification {
    private int notificationId;
    private int studentId;
    private String message;
    private String type;
    private String generatedBy;
    private Timestamp timestamp;

    public Notification() {}

    public Notification(int notificationId, int studentId, String message, String type,
                        String generatedBy, Timestamp timestamp) {
        this.notificationId = notificationId;
        this.studentId = studentId;
        this.message = message;
        this.type = type;
        this.generatedBy = generatedBy;
        this.timestamp = timestamp;
    }

    public int getNotificationId() { return notificationId; }
    public void setNotificationId(int notificationId) { this.notificationId = notificationId; }

    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getGeneratedBy() { return generatedBy; }
    public void setGeneratedBy(String generatedBy) { this.generatedBy = generatedBy; }

    public Timestamp getTimestamp() { return timestamp; }
    public void setTimestamp(Timestamp timestamp) { this.timestamp = timestamp; }
    @Override
    public String toString() {
        return "Notification [notificationId=" + notificationId + ", studentId=" + studentId +
                ", message=" + message + ", type=" + type + ", generatedBy=" + generatedBy +
                ", timestamp=" + timestamp + "]";
    }
}
