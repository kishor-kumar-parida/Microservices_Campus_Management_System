package day8;
public class Faculty {
    private int facultyId;
    private String name;
    private String email;
    private String department;
    private String designation;

    public Faculty() {}

    public Faculty(int facultyId, String name, String email, String department, String designation) {
        this.facultyId = facultyId;
        this.name = name;
        this.email = email;
        this.department = department;
        this.designation = designation;
    }

    public int getFacultyId() { return facultyId; }
    public void setFacultyId(int facultyId) { this.facultyId = facultyId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getDesignation() { return designation; }
    public void setDesignation(String designation) { this.designation = designation; }
    @Override
    public String toString() {
        return "Faculty [facultyId=" + facultyId + ", name=" + name + ", email=" + email +
                ", department=" + department + ", designation=" + designation + "]";
    }
}